package ch.zli.m223;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class BookingResourceIT extends BookingResourceTest {
    // Execute the same tests but in packaged mode.
}
