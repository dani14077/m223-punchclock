package ch.zli.m223;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class UserResourceIT extends UserResourceTest {
    // Execute the same tests but in packaged mode.
}
